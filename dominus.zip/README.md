# [Dominus Gestão](https://www.dominusgestao.com.br/)

[Dominus Gestão](https://www.dominusgestao.com.br/) é um sistema pensado e desenvolvido exclusivamente para a Gestão Condominial, oferecendo várias funcionalidades capazes de se adaptar ao seu Condomínio.

Adotando o Dominus, em apenas três meses já será possível observar a melhora significativa no aproveitamento do tempo do gestor, gerando também economia para o Condomínio. 
